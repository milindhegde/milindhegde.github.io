The code for simulating the ASEP sheet as well as ASEP landscape is provided in the file ASEP_simulations.jl. 

The code is written in the open-source scientific programming language Julia (julialang.org). After Julia is installed, it can be run from the command-line or also in a Jupyter notebook (jupyter.org); a guide for installing Jupyter with Julia is available, for example, at datatofish.com/add-julia-to-jupyter.

The code will also be available (and perhaps updated) on the website of Milind Hegde, currently math.columbia.edu/~milind.